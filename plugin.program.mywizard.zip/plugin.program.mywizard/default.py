import xbmc, xbmcgui, xbmcaddon
import os, shutil, zipfile, urllib.request

ADDON_ID = 'plugin.program.mywizard'
BUILD_URL = 'https://example.com/MyKodiBuild.zip'  # << replace this
ZIP_PATH = xbmc.translatePath('special://home/temp/build.zip')

# Confirm install
dialog = xbmcgui.Dialog()
if dialog.yesno("Kodi Build Installer", "Install custom build now?"):

    # Download the ZIP
    urllib.request.urlretrieve(BUILD_URL, ZIP_PATH)

    # Wipe existing userdata and addons
    shutil.rmtree(xbmc.translatePath('special://home/userdata'), ignore_errors=True)
    shutil.rmtree(xbmc.translatePath('special://home/addons'), ignore_errors=True)

    # Unzip new build
    with zipfile.ZipFile(ZIP_PATH, 'r') as zip_ref:
        zip_ref.extractall(xbmc.translatePath('special://home'))

    dialog.ok("Success", "Restart Kodi to finish installation.")